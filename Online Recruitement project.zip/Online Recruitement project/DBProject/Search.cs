﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace DBProject
{
    public partial class Search : Form
    {
        private int userID;
        private string type;
        public Search(int UserID, string Type)
        {
            InitializeComponent();
            userID = UserID;
            type = Type;
        }
        

         

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=LAPTOP-JFMTUINJ\\SQLEXPRESS;Initial Catalog=onlineRecruitmentSystem;Integrated Security=True";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                if (type == "Employer")
                {
                    string query1 = "SELECT * FROM Employer WHERE EmployerID = @empID";
                    using (SqlCommand command1 = new SqlCommand(query1, connection))
                    {
                        command1.Parameters.AddWithValue("@empID", userID);
                        using (SqlDataReader reader1 = command1.ExecuteReader())
                        {
                            if (reader1.Read())
                            {
                                this.Hide();
                                employerAcc employerAcc = new employerAcc(userID, type);
                                employerAcc.Show();

                                return;
                            }
                        }
                    }
                }
                else if (type == "JobSeeker")
                {


                    string query2 = "SELECT * FROM JobSeeker WHERE JobSeekerID = @seekerID";
                    using (SqlCommand command2 = new SqlCommand(query2, connection))
                    {
                        command2.Parameters.AddWithValue("@seekerID", userID);
                        using (SqlDataReader reader2 = command2.ExecuteReader())
                        {
                            if (reader2.Read())
                            {
                                this.Hide();
                                seekerAcc seekerAcc = new seekerAcc(userID, type);
                                seekerAcc.Show();

                                return;
                            }
                        }
                    }
                }
            }
        }

        private DataTable MostInteresting()
        {
            string connectionString = "Data Source=LAPTOP-JFMTUINJ\\SQLEXPRESS;Initial Catalog=onlineRecruitmentSystem;Integrated Security=True";
            DataTable table = new DataTable();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query1 = "SELECT V.Title, COUNT(JI.JobSeekerID) AS ApplicantCount FROM Vacancy V JOIN JobInterest JI ON V.VacancyID = JI.VacancyID GROUP BY V.Title HAVING COUNT(JI.JobSeekerID) = (SELECT MAX(ApplicantCount) FROM (SELECT COUNT(JI2.JobSeekerID) AS ApplicantCount FROM Vacancy V2 JOIN JobInterest JI2 ON V2.VacancyID = JI2.VacancyID GROUP BY V2.Title) AS Counts)";
                using (SqlCommand command = new SqlCommand(query1, connection))
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    adapter.Fill(table);
                }
            }
            return table;

        }


        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            DataTable InterestingJobs = MostInteresting();
            this.Hide();
            searchResults results = new searchResults(userID, InterestingJobs, type);
            results.Show();

        }

        private DataTable NoInterest()
        {
            string connectionString = "Data Source=LAPTOP-JFMTUINJ\\SQLEXPRESS;Initial Catalog=onlineRecruitmentSystem;Integrated Security=True";
            DataTable table = new DataTable();
            DateTime now = DateTime.Now;
            DateTime firstDayLastMonth = new DateTime(now.Year, now.Month, 1).AddMonths(-1);
            DateTime lastDayLastMonth = new DateTime(now.Year, now.Month, 1).AddDays(-1);
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query2 = "SELECT V.Title FROM Vacancy V WHERE V.DatePosted >= @FirstDayLastMonth and V.DatePosted <= @LastDayLastMonth AND NOT EXISTS(SELECT 1 FROM JobInterest JI WHERE JI.VacancyID = V.VacancyID)";
                using (SqlCommand command = new SqlCommand(query2, connection))
                {
                    command.Parameters.AddWithValue("@FirstDayLastMonth", firstDayLastMonth);
                    command.Parameters.AddWithValue("@LastDayLastMonth", lastDayLastMonth);
                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        adapter.Fill(table);
                    }
                }
            }
            return table;
        }
        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            DataTable NoInterestJobs = NoInterest();
            this.Hide();
            searchResults results = new searchResults(userID, NoInterestJobs, type);
            results.Show();

        }

        private DataTable MaxPosted()
        {
            string connectionString = "Data Source=LAPTOP-JFMTUINJ\\SQLEXPRESS;Initial Catalog=onlineRecruitmentSystem;Integrated Security=True";
            DataTable table = new DataTable();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query3 = "SELECT Employer.Name, COUNT(*) AS AnnouncementCount FROM Vacancy JOIN Employer ON Vacancy.EmployerID = Employer.EmployerID WHERE DatePosted >= CAST(DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()) - 1, 0) AS DATE) AND DatePosted<CAST(DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0) AS DATE) GROUP BY Employer.Name HAVING COUNT(*) = (SELECT MAX(VacancyCount) FROM(SELECT COUNT(*) AS VacancyCount FROM Vacancy WHERE DatePosted >= CAST(DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()) - 1, 0) AS DATE) AND DatePosted < CAST(DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0) AS DATE) GROUP BY EmployerID) AS SubCounts)";
                using (SqlCommand command = new SqlCommand(query3, connection))
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    adapter.Fill(table);
                }
            }
            return table;
        }
        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            DataTable MaxPostedJobs = MaxPosted();
            this.Hide();
            searchResults results = new searchResults(userID, MaxPostedJobs, type);
            results.Show();

        }

        private DataTable NoVacancy()
        {
            string connectionString = "Data Source=LAPTOP-JFMTUINJ\\SQLEXPRESS;Initial Catalog=onlineRecruitmentSystem;Integrated Security=True";
            DataTable table = new DataTable();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query4 = "SELECT Name FROM Employer WHERE EmployerID NOT IN(SELECT EmployerID FROM Vacancy WHERE DatePosted >= CAST(DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()) - 1, 0) AS DATE) AND DatePosted<CAST(DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0) AS DATE))";
                using (SqlCommand command = new SqlCommand(query4, connection))
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    adapter.Fill(table);
                }
            }
            return table;
        }

        private void linkLabel4_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            DataTable NoVacancyJobs = NoVacancy();
            this.Hide();
            searchResults results = new searchResults(userID, NoVacancyJobs, type);
            results.Show();
        }

        private DataTable AllPostedVacancies()
        {
            string connectionString = "Data Source=LAPTOP-JFMTUINJ\\SQLEXPRESS;Initial Catalog=onlineRecruitmentSystem;Integrated Security=True";
            DataTable table = new DataTable();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query5 = "SELECT e.Name AS EmployerName, v.Title AS VacancyTitle, v.DatePosted FROM Employer e INNER JOIN Vacancy v ON e.EmployerID = v.EmployerID WHERE v.Availability = 1 AND v.DatePosted >= CAST(DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()) - 1, 0) AS DATE) AND v.DatePosted < CAST(DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0) AS DATE) ORDER BY e.Name, v.DatePosted;";
                using (SqlCommand command = new SqlCommand(query5, connection))
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    adapter.Fill(table);
                }
            }
            return table;
        }
        private void linkLabel5_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            DataTable totalJobs = AllPostedVacancies();
            this.Hide();
            searchResults results = new searchResults(userID, totalJobs, type);
            results.Show();

        }


        private DataTable JobSeekerInfo()
        {
            string connectionString = "Data Source=LAPTOP-JFMTUINJ\\SQLEXPRESS;Initial Catalog=onlineRecruitmentSystem;Integrated Security=True";
            DataTable table = new DataTable();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query6 = "SELECT js.JobSeekerID, js.Name, js.Email, js.Phone, js.Age, js.Gender, js.Industry, js.Governate, js.City, js.CVLink, js.YearsOfExperience, js.CareerLevel, COUNT(ji.JobInterestID) AS NumberOfApplications FROM JobSeeker js LEFT JOIN JobInterest ji ON js.JobSeekerID = ji.JobSeekerID GROUP BY js.JobSeekerID, js.Name, js.Email, js.Phone, js.Age, js.Gender, js.Industry, js.Governate, js.City, js.CVLink, js.YearsOfExperience, js.CareerLevel ORDER BY js.Name;";
                using (SqlCommand command = new SqlCommand(query6, connection))
                using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                {
                    adapter.Fill(table);
                }
            }
            return table;
        }
        private void linkLabel6_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            DataTable JobSeekerInfoJobs = JobSeekerInfo();
            this.Hide();
            searchResults results = new searchResults(userID, JobSeekerInfoJobs, type);
            results.Show();

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            string term = searchbox.Text;
            string connectionString = "Data Source=LAPTOP-JFMTUINJ\\SQLEXPRESS;Initial Catalog=onlineRecruitmentSystem;Integrated Security=True";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = @"SELECT v.VacancyID, v.Title, v.Description, e.Name AS EmployerName, v.Governate, v.City, v.DatePosted FROM Vacancy v INNER JOIN Employer e ON v.EmployerID = e.EmployerID WHERE (v.Title LIKE @search OR v.Description LIKE @search) AND v.Availability = 1 ORDER BY v.DatePosted DESC";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@search", "%" + term + "%");
                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        DataTable results = new DataTable();
                        adapter.Fill(results);

                        listView1.Items.Clear();
                        listView1.View = View.Details;
                        listView1.FullRowSelect = true;

                        if (listView1.Columns.Count == 0)
                        {
                            listView1.Columns.Add("Title", 150);
                            listView1.Columns.Add("Description", 200);
                            listView1.Columns.Add("Employer", 120);
                            listView1.Columns.Add("Governate", 100);
                            listView1.Columns.Add("City", 100);
                            listView1.Columns.Add("Date Posted", 120);
                        }

                        foreach (DataRow row in results.Rows)
                        {
                            ListViewItem item = new ListViewItem(row["Title"].ToString());
                            item.SubItems.Add(row["Description"].ToString());
                            item.SubItems.Add(row["EmployerName"].ToString());
                            item.SubItems.Add(row["Governate"].ToString());
                            item.SubItems.Add(row["City"].ToString());
                            item.SubItems.Add(Convert.ToDateTime(row["DatePosted"]).ToShortDateString());
                            item.Tag = row["VacancyID"]; 
                            listView1.Items.Add(item);
                        }
                    }
                
                }

            }
        }

        private void searchingcards_Paint(object sender, PaintEventArgs e)
        {

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Search_Load(object sender, EventArgs e)
        {

        }

        private void applying_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count == 0)
            {
                MessageBox.Show("Please select a vacancy to apply to.");
                return;
            }

            ListViewItem selectedItem = listView1.SelectedItems[0];
            int vacancyID = Convert.ToInt32(selectedItem.Tag);

            string connectionString = "Data Source=LAPTOP-JFMTUINJ\\SQLEXPRESS;Initial Catalog=onlineRecruitmentSystem;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string checkQuery = "SELECT COUNT(*) FROM JobInterest WHERE JobSeekerID = @userID AND VacancyID = @vacancyID";
                using (SqlCommand checkCmd = new SqlCommand(checkQuery, connection))
                {
                    checkCmd.Parameters.AddWithValue("@userID", userID);
                    checkCmd.Parameters.AddWithValue("@vacancyID", vacancyID);
                    int count = (int)checkCmd.ExecuteScalar();

                    if (count > 0)
                    {
                        MessageBox.Show("You have already applied for this vacancy.");
                        return;
                    }
                }

                string insertQuery = "INSERT INTO JobInterest (JobSeekerID, VacancyID, Date, Status) VALUES (@userID, @vacancyID, @dateApplied, @status)";
                using (SqlCommand command = new SqlCommand(insertQuery, connection))
                {
                    command.Parameters.AddWithValue("@userID", userID);
                    command.Parameters.AddWithValue("@vacancyID", vacancyID);
                    command.Parameters.AddWithValue("@dateApplied", DateTime.Now);
                    command.Parameters.AddWithValue("@status", "Applied");

                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Application submitted successfully!");
                    }
                    else
                    {
                        MessageBox.Show("An error occurred while applying. Please try again.");
                    }
                }
            }
        }

        private void saving_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count == 0)
            {
                MessageBox.Show("Please select a vacancy to save.");
                return;
            }

            ListViewItem selectedItem = listView1.SelectedItems[0];
            int vacancyID = Convert.ToInt32(selectedItem.Tag);

            string connectionString = "Data Source=LAPTOP-JFMTUINJ\\SQLEXPRESS;Initial Catalog=onlineRecruitmentSystem;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string checkQuery = "SELECT COUNT(*) FROM JobInterest WHERE JobSeekerID = @userID AND VacancyID = @vacancyID";
                using (SqlCommand checkCmd = new SqlCommand(checkQuery, connection))
                {
                    checkCmd.Parameters.AddWithValue("@userID", userID);
                    checkCmd.Parameters.AddWithValue("@vacancyID", vacancyID);
                    int count = (int)checkCmd.ExecuteScalar();

                    if (count > 0)
                    {
                        MessageBox.Show("You have already saved this vacancy.");
                        return;
                    }
                }

                string insertQuery = "INSERT INTO JobInterest (JobSeekerID, VacancyID, IsSaved) VALUES (@userID, @vacancyID, @saved)";
                using (SqlCommand command = new SqlCommand(insertQuery, connection))
                {
                    command.Parameters.AddWithValue("@userID", userID);
                    command.Parameters.AddWithValue("@vacancyID", vacancyID);
                    command.Parameters.AddWithValue("@saved", true);

                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Vacancy saved successfully!");
                    }
                    else
                    {
                        MessageBox.Show("An error occurred while saving. Please try again.");
                    }
                }
            }
        }
    }
}


