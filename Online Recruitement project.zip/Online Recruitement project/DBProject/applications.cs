﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBProject
{
    public partial class applications : Form
    {
        private int SeekerID;
        private string type;
        public applications(int seekerID, string type)
        {
            InitializeComponent();
            this.SeekerID = seekerID;
            this.type = type;
        }

        private void LoadAppData()
        {

            listView1.Items.Clear();
            string connectionString = "Data Source=LAPTOP-JFMTUINJ\\SQLEXPRESS;Initial Catalog=onlineRecruitmentSystem;Integrated Security=True";
            string query = "SELECT Name FROM JobSeeker WHERE JobSeekerID = @seekerID";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@seekerID", SeekerID);

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            Fname.Text = reader["Name"].ToString();
                        }
                    }
                }
            }

            string query1 = "SELECT JI.JobInterestID, JI.Date, JI.Status, V.Title FROM JobInterest JI JOIN Vacancy V ON JI.VacancyID = V.VacancyID WHERE JI.JobSeekerID = @seekerID";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand(query1, connection))
                {
                    command.Parameters.AddWithValue("@seekerID", SeekerID);
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            ListViewItem item = new ListViewItem(reader["JobInterestID"].ToString());
                            item.SubItems.Add(reader["Title"].ToString());
                            item.SubItems.Add(reader["Date"].ToString());
                            item.SubItems.Add(reader["Status"].ToString());


                            listView1.Items.Add(item);
                        }
                    }
                }
            }
        }
        private void applications_Load(object sender, EventArgs e)
        {
            LoadAppData();
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void acc_Click(object sender, EventArgs e)
        {
            this.Hide();
            seekerAcc seekeracc = new seekerAcc(SeekerID, type);
            seekeracc.Show();
        }
    }
}
