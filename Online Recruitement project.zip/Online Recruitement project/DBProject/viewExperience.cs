﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBProject
{
    public partial class viewExperience : Form
    {
        int SeekerID;
        string type;
        public viewExperience(int seekerID, string type)
        {
            InitializeComponent();
            this.SeekerID = seekerID;
            this.type = type;
        }

        private void LoadExpData()
        {

            listView1.Items.Clear();
            string connectionString = "Data Source=LAPTOP-JFMTUINJ\\SQLEXPRESS;Initial Catalog=onlineRecruitmentSystem;Integrated Security=True";
            string query = "SELECT Name FROM JobSeeker WHERE JobSeekerID = @seekerID";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@seekerID", SeekerID);

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            Fname.Text = reader["Name"].ToString();
                        }
                    }
                }
            }

            string query1 = "SELECT Role, Company, Duration, Description, ExperienceID FROM Experience WHERE JobSeekerID = @seekerID";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand(query1, connection))
                {
                    command.Parameters.AddWithValue("@seekerID", SeekerID);
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            ListViewItem item = new ListViewItem(reader["Role"].ToString());
                            item.SubItems.Add(reader["Company"].ToString());
                            item.SubItems.Add(reader["Duration"].ToString());
                            item.SubItems.Add(reader["Description"].ToString());
                            item.Tag = reader["ExperienceID"].ToString();

                            listView1.Items.Add(item);
                        }
                    }
                }
            }
        }

        
        private void viewExperience_Load(object sender, EventArgs e)
        {
           LoadExpData();
        }

        private void acc_Click(object sender, EventArgs e)
        {
            this.Hide();
            seekerAcc f2 = new seekerAcc(SeekerID, type);
            f2.Show();
        }

        private void del_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count == 0)
            {
                MessageBox.Show("Please select experience to be delete.");
                return;
            }

            var confirm = MessageBox.Show("Are you sure you want to delete this work experience?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (confirm != DialogResult.Yes)
                return;

            ListViewItem selectedItem = listView1.SelectedItems[0];
            int ExpID = int.Parse(selectedItem.Tag.ToString()); 

            string connectionString = "Data Source=LAPTOP-JFMTUINJ\\SQLEXPRESS;Initial Catalog=onlineRecruitmentSystem;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string deleteQuery = "DELETE FROM Experience WHERE ExperienceID = @expID";
                using (SqlCommand command = new SqlCommand(deleteQuery, connection))
                {
                    command.Parameters.AddWithValue("@expID", ExpID);
                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        listView1.Items.Remove(selectedItem);
                        MessageBox.Show("Vacancy deleted successfully.");
                        LoadExpData();
                    }
                    else
                    {
                        MessageBox.Show("Failed to delete vacancy.");
                    }
                }
            }
        }
    }
}
