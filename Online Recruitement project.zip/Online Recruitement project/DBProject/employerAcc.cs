﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.LinkLabel;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TextBox;
using System.Xml.Linq;

namespace DBProject
{
    public partial class employerAcc : Form

    {
        private string emaill;
        private string pass;
        private int employerID;
        private string Type;

        public employerAcc(int empID, string type)
        {
            InitializeComponent();
            employerID = empID;
            Type = type;
        }
        

        private void LoadUserData()
        {
            string connectionString = "Data Source=LAPTOP-JFMTUINJ\\SQLEXPRESS;Initial Catalog=onlineRecruitmentSystem;Integrated Security=True";


            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                

                string query2 = "SELECT * FROM Employer WHERE EmployerID = @empID";
                using (SqlCommand command1 = new SqlCommand(query2, connection))
                {
                    command1.Parameters.AddWithValue("@empID", employerID);
                    using (SqlDataReader reader1 = command1.ExecuteReader())
                    {
                        if (reader1.Read())
                        {
                            employerID = (int)reader1["EmployerID"];
                            fName.Text = reader1["Name"].ToString();
                            employerage.Text = reader1["Age"].ToString();
                            email.Text = reader1["Email"].ToString();
                            phone.Text = reader1["Phone"].ToString();
                            password.Text = reader1["Password"].ToString();
                            city.Text = reader1["City"].ToString();
                            industryList.SelectedItem = reader1["Industry"].ToString();
                            governate.SelectedItem = reader1["Governate"].ToString();
                            cName.Text = reader1["CompanyName"].ToString();
                            if (reader1["Gender"].ToString() == "Female")
                            {
                                female.Checked = true;
                            }
                            else if (reader1["Gender"].ToString() == "Male")
                            {
                                male.Checked = true;
                            }
                        }

                    }

                }
            }
        }
        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            createVacancy f2 = new createVacancy(employerID, Type);
            this.Hide();
            f2.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string name = fName.Text.Trim();
            int age = int.Parse(employerage.Text.Trim());
            string industryname = industryList.SelectedItem.ToString();
            string phoneNum = phone.Text.Trim();
            string emailAdd = email.Text.Trim();
            string pass = password.Text.Trim();
            string cityy = city.Text.Trim();
            string governatee = governate.SelectedItem.ToString();
            string cNamee = cName.Text.Trim();
            string gender = "";

            if (female.Checked)
            {
                gender = "Female";
            }
            else if (male.Checked)
            {
                gender = "Male";
            }

            if (age < 18)
            {
                MessageBox.Show("You must be at least 18 years old to register.");
                return;
            }



            string connectionString = "Data Source=LAPTOP-JFMTUINJ\\SQLEXPRESS;Initial Catalog=onlineRecruitmentSystem;Integrated Security=True";


            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query1 = "UPDATE Employer SET Name = @Name, Email = @Email, Password = @Password, Phone = @Phone, Age = @Age, Gender = @Gender, Industry = @Industry, City = @City, Governate = @Governate, CompanyName = @Company WHERE EmployerID = @employerID";
                using (SqlCommand command1 = new SqlCommand(query1, connection))
                {
                    command1.Parameters.AddWithValue("@Email", emailAdd);
                    command1.Parameters.AddWithValue("@Name", name);
                    command1.Parameters.AddWithValue("gender", gender);
                    command1.Parameters.AddWithValue("@Phone", phoneNum);
                    command1.Parameters.AddWithValue("@Age", age);
                    command1.Parameters.AddWithValue("@Industry", industryname);
                    command1.Parameters.AddWithValue("@Password", pass);
                    command1.Parameters.AddWithValue("@City", cityy);
                    command1.Parameters.AddWithValue("@Governate", governatee);
                    command1.Parameters.AddWithValue("@Company", cNamee);
                    command1.Parameters.AddWithValue("@employerID", employerID);
                    command1.ExecuteNonQuery();

                    LoadUserData();
                }





            }
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void employerAcc_Load(object sender, EventArgs e)
        {
            LoadUserData();
        }

        private void vacList_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            viewVacancy viewvac = new viewVacancy(employerID,Type);
            viewvac.Show();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Search search = new Search(employerID, Type);
            search.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            login log = new login();
            log.Show();
        }
    }
}
