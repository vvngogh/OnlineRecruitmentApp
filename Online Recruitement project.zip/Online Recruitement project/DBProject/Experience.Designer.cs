﻿namespace DBProject
{
    partial class Experience
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Role = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Description = new System.Windows.Forms.RichTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.Company = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.Duration = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.expList = new System.Windows.Forms.LinkLabel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.acc = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(68, 193);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Role:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(191, 83);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(174, 36);
            this.label2.TabIndex = 1;
            this.label2.Text = "Experience";
            // 
            // Role
            // 
            this.Role.Location = new System.Drawing.Point(181, 193);
            this.Role.Name = "Role";
            this.Role.Size = new System.Drawing.Size(200, 22);
            this.Role.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(63, 427);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(112, 20);
            this.label3.TabIndex = 3;
            this.label3.Text = "Description:";
            // 
            // Description
            // 
            this.Description.Location = new System.Drawing.Point(181, 394);
            this.Description.Name = "Description";
            this.Description.Size = new System.Drawing.Size(225, 118);
            this.Description.TabIndex = 4;
            this.Description.Text = "";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(63, 257);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(92, 20);
            this.label4.TabIndex = 5;
            this.label4.Text = "Company:";
            // 
            // Company
            // 
            this.Company.Location = new System.Drawing.Point(181, 255);
            this.Company.Name = "Company";
            this.Company.Size = new System.Drawing.Size(200, 22);
            this.Company.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(63, 326);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(87, 20);
            this.label5.TabIndex = 9;
            this.label5.Text = "Duration:";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // Duration
            // 
            this.Duration.Location = new System.Drawing.Point(181, 326);
            this.Duration.Name = "Duration";
            this.Duration.Size = new System.Drawing.Size(200, 22);
            this.Duration.TabIndex = 12;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Gold;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(267, 581);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(178, 52);
            this.button2.TabIndex = 63;
            this.button2.Text = "Add Experience";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // expList
            // 
            this.expList.AutoSize = true;
            this.expList.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.expList.Location = new System.Drawing.Point(462, 613);
            this.expList.Name = "expList";
            this.expList.Size = new System.Drawing.Size(158, 20);
            this.expList.TabIndex = 64;
            this.expList.TabStop = true;
            this.expList.Text = "View Experiences";
            this.expList.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::DBProject.Properties.Resources.exper;
            this.pictureBox1.Location = new System.Drawing.Point(466, 61);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(230, 216);
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // acc
            // 
            this.acc.BackColor = System.Drawing.Color.Gold;
            this.acc.Cursor = System.Windows.Forms.Cursors.Hand;
            this.acc.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.acc.Location = new System.Drawing.Point(56, 581);
            this.acc.Name = "acc";
            this.acc.Size = new System.Drawing.Size(147, 52);
            this.acc.TabIndex = 94;
            this.acc.Text = "Account";
            this.acc.UseVisualStyleBackColor = false;
            this.acc.Click += new System.EventHandler(this.acc_Click);
            // 
            // Experience
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Ivory;
            this.ClientSize = new System.Drawing.Size(708, 746);
            this.Controls.Add(this.acc);
            this.Controls.Add(this.expList);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.Duration);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.Company);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Description);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Role);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Experience";
            this.Text = "Experience";
            this.Load += new System.EventHandler(this.Experience_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox Role;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RichTextBox Description;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox Company;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox Duration;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.LinkLabel expList;
        private System.Windows.Forms.Button acc;
    }
}