﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace DBProject
{
    public static class DB 
    {
        public static string ConnectionString { get; set; } = "Server=tcp:LAPTOP-JFMTUINJ\\SQLEXPRESS;Database=onlineRecruitmentSystem;User Id=userRecruitment;Password=database21;";
        public static SqlConnection GetConnection()
        {
            return new SqlConnection(ConnectionString);
        }
        public static void ExecuteQuery(string query)
        {
            using (var connection = GetConnection())
            {
                connection.Open();
                using (var command = new SqlCommand(query, connection))
                {
                    command.ExecuteNonQuery();
                }
            }
        }
        public static SqlDataReader ExecuteReader(string query)
        {
            var connection = GetConnection();
            var command = new SqlCommand(query, connection);
            connection.Open();
            return command.ExecuteReader(CommandBehavior.CloseConnection);
        }
    }
}
