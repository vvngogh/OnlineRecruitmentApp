﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DBProject
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            userType f2 = new userType();
            f2.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string email = textBox3.Text.Trim();
            string password = textBox4.Text.Trim();
            int userID = 0;
            string Type = "";

            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Please enter login information.");
                return;
            }
            string connectionString = "Data Source=LAPTOP-JFMTUINJ\\SQLEXPRESS;Initial Catalog=onlineRecruitmentSystem;Integrated Security=True";


            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query1 = "SELECT EmployerID FROM Employer WHERE Email = @Email AND Password = @Password";
                using (SqlCommand command1 = new SqlCommand(query1, connection))
                {
                    command1.Parameters.AddWithValue("@Email", email);
                    command1.Parameters.AddWithValue("@Password", password);
                    using (SqlDataReader reader1 = command1.ExecuteReader())
                    {
                        if (reader1.Read())
                        {
                            userID = (int)reader1["EmployerID"];
                            Type = "Employer";
                            this.Hide();
                            employerAcc employerAcc = new employerAcc(userID, Type);
                            employerAcc.Show();

                            return;
                        }
                    }
                }

                string query2 = "SELECT JobSeekerID FROM JobSeeker WHERE Email = @Email AND Password = @Password";
                using (SqlCommand command2 = new SqlCommand(query2, connection))
                {
                    command2.Parameters.AddWithValue("@Email", email);
                    command2.Parameters.AddWithValue("@Password", password);
                    using (SqlDataReader reader2 = command2.ExecuteReader())
                    {
                        if (reader2.Read())
                        {
                            userID = (int)reader2["JobSeekerID"];
                            Type = "JobSeeker";
                            this.Hide();
                            seekerAcc seekerAcc = new seekerAcc(userID, Type);
                            seekerAcc.Show();

                            return;
                        }
                    }
                }
            MessageBox.Show("Invalid email or password.");
                   
              
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
