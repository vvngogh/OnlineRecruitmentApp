﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DBProject
{
    public partial class seekerAcc : Form
    {
        private string emaill;
        private string pass;
        private int SeekerID;
        private string Type;


        public seekerAcc(int seekerID, string type)
        {
            InitializeComponent();
            SeekerID = seekerID;
            Type = type;
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void LoadUserData()
        {
            string connectionString = "Data Source=LAPTOP-JFMTUINJ\\SQLEXPRESS;Initial Catalog=onlineRecruitmentSystem;Integrated Security=True";


            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                

                string query2 = "SELECT * FROM JobSeeker WHERE JobSeekerID = @seekerID";
                using (SqlCommand command1 = new SqlCommand(query2, connection))
                {
                    command1.Parameters.AddWithValue("@seekerID", SeekerID);
                    using (SqlDataReader reader1 = command1.ExecuteReader())
                    {
                        if (reader1.Read())
                        {
                            SeekerID = (int)reader1["JobSeekerID"];
                            fName.Text = reader1["Name"].ToString();
                            seekerage.Text = reader1["Age"].ToString();
                            email.Text = reader1["Email"].ToString();
                            phone.Text = reader1["Phone"].ToString();
                            password.Text = reader1["Password"].ToString();
                            city.Text = reader1["City"].ToString();
                            industryList.SelectedItem = reader1["Industry"].ToString();
                            governate.SelectedItem = reader1["Governate"].ToString();
                            link.Text = reader1["CVLink"].ToString();
                            years.Text = reader1["YearsOfExperience"].ToString();
                            career.SelectedItem = reader1["CareerLevel"].ToString();
                            if (reader1["Gender"].ToString() == "Female")
                            {
                                female.Checked = true;
                            }
                            else if (reader1["Gender"].ToString() == "Male")
                            {
                                male.Checked = true;
                            }
                        }

                    }

                }
            }
        }

        private void seekerAcc_Load(object sender, EventArgs e)
        {

            LoadUserData();

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string name = fName.Text.Trim();
            int age = int.Parse(seekerage.Text.Trim());
            string industryname = industryList.SelectedItem.ToString();
            string phoneNum = phone.Text.Trim();
            string emailAdd = email.Text.Trim();
            string pass = password.Text.Trim();
            string cityy = city.Text.Trim();
            string governatee = governate.SelectedItem.ToString();
            string cvlink = link.Text.Trim();
            int yearsOfExperience = int.Parse(years.Text.Trim());
            string careerLevel = career.SelectedItem.ToString();

            string gender = "";

            if (female.Checked)
            {
                gender = "Female";
            }
            else if (male.Checked)
            {
                gender = "Male";
            }

            if (age < 18)
            {
                MessageBox.Show("You must be at least 18 years old to register.");
                return;
            }

           

            string connectionString = "Data Source=LAPTOP-JFMTUINJ\\SQLEXPRESS;Initial Catalog=onlineRecruitmentSystem;Integrated Security=True";


            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query1 = "UPDATE JobSeeker SET Name = @Name, Email = @Email, Password = @Password, Phone = @Phone, Age = @Age, Gender = @Gender, Industry = @Industry, City = @City, Governate = @Governate, CVLink = @Cvlink, YearsOfExperience = @YOExp, CareerLevel = @careerLevel WHERE JobSeekerID = @seekerID";
                using (SqlCommand command1 = new SqlCommand(query1, connection))
                {
                    command1.Parameters.AddWithValue("@Email", emailAdd);
                    command1.Parameters.AddWithValue("@Name", name);
                    command1.Parameters.AddWithValue("gender", gender);
                    command1.Parameters.AddWithValue("@Phone", phoneNum);
                    command1.Parameters.AddWithValue("@Age", age);
                    command1.Parameters.AddWithValue("@Industry", industryname);
                    command1.Parameters.AddWithValue("@Password", pass);
                    command1.Parameters.AddWithValue("@City", cityy);
                    command1.Parameters.AddWithValue("@Governate", governatee);
                    command1.Parameters.AddWithValue("@Cvlink", cvlink);
                    command1.Parameters.AddWithValue("@YOExp", yearsOfExperience);
                    command1.Parameters.AddWithValue("@careerLevel", careerLevel);
                    command1.Parameters.AddWithValue("@seekerID", SeekerID);
                    command1.ExecuteNonQuery();
                    
                    LoadUserData();
                }



            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            viewExperience viewexp = new viewExperience(SeekerID, Type);
            viewexp.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Experience exp = new Experience(SeekerID, Type);
            exp.Show();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Search search = new Search(SeekerID,Type );
            search.Show();
        }

        private void applied_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            applications applied = new applications(SeekerID, Type);
            applied.Show();
        }

        private void saved_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            savedVac saved = new savedVac(SeekerID, Type);
            saved.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            login Log = new login();
            Log.Show();
        }
    }
}
