﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using System.Xml.Linq;

namespace DBProject
{
    public partial class viewVacancy : Form
    {
        private ComboBox editor = new ComboBox();
        private int employerID;
        private string Type;
        public viewVacancy(int employerID, string Type)
        {
            InitializeComponent();
            this.employerID = employerID;
            this.Type = Type;

            editor.Visible = false;
            editor.DropDownStyle = ComboBoxStyle.DropDown;
            editor.Items.AddRange(new string[] { "Yes", "No" });
            editor.Leave+= editor_Leave;
            editor.SelectedIndexChanged += editor_SelectedIndexChanged;
            this.Controls.Add(editor);
            listView1.MouseDoubleClick += listView1_MouseDoubleClick;
        }

        private void LoadVacancyData()
        {
            listView1.Clear();
            listView1.LabelEdit = true;
            listView1.View = View.Details;

            listView1.Columns.Add("Availability");
            listView1.Columns.Add("Title");
            listView1.Columns.Add("Industry");
            listView1.Columns.Add("Description");
            listView1.Columns.Add("Years of Experience");
            listView1.Columns.Add("Career Level");
            listView1.Columns.Add("Governate");
            listView1.Columns.Add("City");
            listView1.Columns.Add("Date Posted");
            string connectionString = "Data Source=LAPTOP-JFMTUINJ\\SQLEXPRESS;Initial Catalog=onlineRecruitmentSystem;Integrated Security=True";
            string query = "SELECT Name FROM Employer WHERE EmployerID = @empID";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@empID", employerID);

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            Fname.Text = reader["Name"].ToString();
                        }
                    }
                }
            }

            string query1 = "SELECT VacancyID, Title, Description, Industry, Availability, YearsOfExperience, CareerLevel, DatePosted, Governate, City FROM Vacancy WHERE EmployerID = @empID";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand(query1, connection))
                {
                    command.Parameters.AddWithValue("@empID", employerID);
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            bool availability = Convert.ToBoolean(reader["Availability"]);
                            string availabilityText = availability ? "Yes" : "No";
                            ListViewItem item = new ListViewItem(availabilityText);
                            item.SubItems.Add(reader["Title"].ToString());
                            item.SubItems.Add(reader["Industry"].ToString());
                            item.SubItems.Add(reader["Description"].ToString());
                            item.SubItems.Add(reader["YearsOfExperience"].ToString());
                            item.SubItems.Add(reader["CareerLevel"].ToString());
                            item.SubItems.Add(reader["Governate"].ToString());
                            item.SubItems.Add(reader["City"].ToString());
                            item.SubItems.Add(reader["DatePosted"].ToString());
                            item.Tag = reader["VacancyID"].ToString(); 

                            listView1.Items.Add(item);
                        }
                    }
                }
            }

        }

        private void viewVacancy_Load(object sender, EventArgs e)
        {
            LoadVacancyData();
        }      

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void listView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            ListViewHitTestInfo info = listView1.HitTest(e.X, e.Y);
            if (info.SubItem != null)
            {
                int index = info.Item.SubItems.IndexOf(info.SubItem);
                if (index == 0)
                {

                    Rectangle bounds = info.SubItem.Bounds;

                    editor.SetBounds(bounds.X, bounds.Y, bounds.Width, bounds.Height);
                    editor.Text = info.SubItem.Text;
                    editor.Tag = info;

                    if(!listView1.Controls.Contains(editor))
                    {
                        listView1.Controls.Add(editor);
                    }
                    editor.Visible = true;
                    editor.BringToFront();
                    editor.Focus();
                }
               
            }
        }

        private void editor_SelectedIndexChanged(object sender, EventArgs e)
{
    CommitEditorValue();
}

        private void editor_Leave(object sender, EventArgs e)
{
    CommitEditorValue();
}

        private void CommitEditorValue()
{
    if (editor.Tag is ListViewHitTestInfo hit)
    {
        hit.SubItem.Text = editor.Text;
        editor.Visible = false;
        listView1.Controls.Remove(editor);
    }
}

        private void button1_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count == 0)
            {
                MessageBox.Show("Please select a vacancy to update.");
                return;
            }

            ListViewItem selectedItem = listView1.SelectedItems[0];
            int vacancyID = int.Parse(selectedItem.Tag.ToString());

            string title = selectedItem.SubItems[1].Text;
            string industry = selectedItem.SubItems[2].Text;
            string description = selectedItem.SubItems[3].Text;
            int yearsOfExperience = int.Parse(selectedItem.SubItems[4].Text);
            string careerLevel = selectedItem.SubItems[5].Text;
            string governate = selectedItem.SubItems[6].Text;
            string city = selectedItem.SubItems[7].Text;
            DateTime datePosted = DateTime.Parse(selectedItem.SubItems[8].Text);
            bool availability = selectedItem.SubItems[0].Text.Trim().ToLower() == "yes";





            string connectionString = "Data Source=LAPTOP-JFMTUINJ\\SQLEXPRESS;Initial Catalog=onlineRecruitmentSystem;Integrated Security=True";


            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query1 = "UPDATE Vacancy SET Availability = @availability WHERE VacancyID = @vacancyID";
                using (SqlCommand command1 = new SqlCommand(query1, connection))
                {
                    
                    command1.Parameters.AddWithValue("@availability", availability);
                    command1.Parameters.AddWithValue("@vacancyID", vacancyID);
                    command1.ExecuteNonQuery();

                    LoadVacancyData();
                }



            }
        }

        private void acc_Click(object sender, EventArgs e)
        {
            this.Hide();
            employerAcc f2 = new employerAcc(employerID, Type);
            f2.Show();
        }
    }
}
