﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBProject
{
    public partial class searchResults : Form
    {
        private int userID;
        private string type;
        public searchResults(int userID, DataTable results, string type)
        {
            InitializeComponent();
            dataGridView1.DataSource = results;
            this.userID = userID;
            this.type = type;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Search search = new Search(userID, type);
            search.Show();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
