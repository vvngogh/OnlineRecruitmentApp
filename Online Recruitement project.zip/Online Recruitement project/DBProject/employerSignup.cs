﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace DBProject
{
    public partial class employerSignup : Form
    {
        public employerSignup()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void password_TextChanged(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            login f2 = new login();
            f2.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string Type = "Employer";
            string name = fName.Text.Trim();
            DateTime dateob = dob.Value;
            string comp = cName.Text.Trim();
            string industryname = industry.SelectedItem.ToString();
            string phone = phoneNum.Text.Trim();
            string emailAdd = email.Text.Trim();
            string pass = password.Text.Trim();
            string gender = "";
            
            if (female.Checked)
            {
                gender = "Female";
            }
            else if (male.Checked)
            {
                gender = "Male";
            }

            if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(comp) || string.IsNullOrEmpty(industryname) || string.IsNullOrEmpty(phone) || string.IsNullOrEmpty(emailAdd) || string.IsNullOrEmpty(gender) || string.IsNullOrEmpty(pass))
            {
                MessageBox.Show("Please fill all of the information.");
                return;
            }

            DateTime Today = DateTime.Today;
            int age = Today.Year - dateob.Year;
            if (age == 0 ){
                MessageBox.Show("Please enter date of birth.");
                return;
            }
            else if(age < 18)
            {
                MessageBox.Show("You must be at least 18 years old to register.");
                return;
            }

            if (pass != confirm.Text)
            {
                MessageBox.Show("Passwords don't match.");
                return;
            }
                
            string connectionString = "Data Source=LAPTOP-JFMTUINJ\\SQLEXPRESS;Initial Catalog=onlineRecruitmentSystem;Integrated Security=True";


            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query1 = "INSERT INTO Employer (Name, Email, Password, Phone, Age, Gender, Industry, CompanyName) VALUES (@Name, @Email, @Password, @Phone, @Age, @Gender, @Industry, @Company)";
                using (SqlCommand command1 = new SqlCommand(query1, connection))
                {
                    command1.Parameters.AddWithValue("@Email", emailAdd);
                    command1.Parameters.AddWithValue("@Name", name);
                    command1.Parameters.AddWithValue("gender", gender);
                    command1.Parameters.AddWithValue("@Phone", phone);
                    command1.Parameters.AddWithValue("@Age", age);
                    command1.Parameters.AddWithValue("@Industry", industryname);
                    command1.Parameters.AddWithValue("@Company", comp);
                    command1.Parameters.AddWithValue("@Password", pass);
                    command1.ExecuteNonQuery();
                    
                }
                string query2 = "SELECT EmployerID FROM Employer WHERE Email = @Email";
                using (SqlCommand command2 = new SqlCommand(query2, connection))
                {
                    command2.Parameters.AddWithValue("@Email", emailAdd);
                    using (SqlDataReader reader2 = command2.ExecuteReader())
                    {
                        if (reader2.Read())
                        {
                            int userID = (int)reader2["EmployerID"];
                            this.Hide();
                            employerAcc employerAcc = new employerAcc(userID, Type);
                            employerAcc.Show();
                            return;
                        }
                    }
                }



            }
        }

        private void fName_TextChanged(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }
    }
}
