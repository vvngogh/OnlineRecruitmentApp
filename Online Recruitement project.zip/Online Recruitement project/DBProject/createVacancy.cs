﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TextBox;

namespace DBProject
{
    public partial class createVacancy : Form
    {
        private int EmployerID;
        private string Type;
        public createVacancy(int EmployeriD, string type)
        {
            InitializeComponent();
            EmployerID = EmployeriD;
            Type = type;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click_1(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void createVacancy_Load(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {


        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        
        private void year_ValueChanged(object sender, EventArgs e)
        {

        }

        private void vacancy_Click(object sender, EventArgs e)
        {
            string jobTitle = Title.Text.Trim();
            string cityName = City.Text.Trim();
            int experienceYears = (int)YearsOfExperience.Value;
            string careerLevel = CareerLevel.SelectedItem?.ToString();
            string industryName = Industry.SelectedItem?.ToString();
            DateTime postDate = DatePosted.Value;
            string jobDescription = Description.Text.Trim();
            string governorateName = governate.SelectedItem?.ToString();


            bool availability;
            if (Availability.SelectedItem?.ToString() == "Yes")
            {
                availability = true;
            }
            else
            {
                availability = false;
            }

            

            if (string.IsNullOrEmpty(jobTitle) ||
                string.IsNullOrEmpty(cityName) ||
                careerLevel == null ||
                industryName == null ||
                jobDescription == null ||
                string.IsNullOrEmpty(governorateName))
            {
                MessageBox.Show("Please fill all required fields.");
                return;
            }

            string connectionString = "Data Source=LAPTOP-JFMTUINJ\\SQLEXPRESS;Initial Catalog=onlineRecruitmentSystem;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = @"INSERT INTO Vacancy
                    (EmployerID, Title, City, YearsOfExperience, CareerLevel, Industry, DatePosted, Availability, Description, Governate)
                    VALUES
                    (@EmployerID, @Title, @City, @YearsOfExperience, @CareerLevel, @Industry, @DatePosted, @Availability, @Description, @Governate)";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@EmployerID", EmployerID);
                    command.Parameters.AddWithValue("@Title", jobTitle);
                    command.Parameters.AddWithValue("@City", cityName);
                    command.Parameters.AddWithValue("@YearsOfExperience", experienceYears);
                    command.Parameters.AddWithValue("@CareerLevel", careerLevel);
                    command.Parameters.AddWithValue("@Industry", industryName);
                    command.Parameters.AddWithValue("@DatePosted", postDate);
                    command.Parameters.AddWithValue("@Availability", availability);
                    command.Parameters.AddWithValue("@Description", jobDescription);
                    command.Parameters.AddWithValue("@Governate", governorateName);

                    command.ExecuteNonQuery();

                    MessageBox.Show("Vacancy posted successfully!");
                   
                }
            }
            Title.Text = string.Empty;
            Description.Text = string.Empty;
            City.Text = string.Empty;
            CareerLevel.SelectedItem = null;
            Industry.SelectedItem = null;
            Availability.SelectedItem = null;
            governate.SelectedItem = null;
            YearsOfExperience.Value = 0;
            DatePosted.Value = DateTime.Now;
            Title.Focus();

        }

        private void expList_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            viewVacancy viewvac = new viewVacancy(EmployerID, Type);
            viewvac.Show();
        }

        private void Governate_TextChanged(object sender, EventArgs e)
        {

        }

        private void acc_Click(object sender, EventArgs e)
        {
            this.Hide();
            employerAcc empHome = new employerAcc(EmployerID, Type);
            empHome.Show();
        }
    }
}
