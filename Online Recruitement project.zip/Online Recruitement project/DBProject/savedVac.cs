﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBProject
{
    public partial class savedVac : Form
    {
        private int SeekerID;
        private string Type;
        public savedVac(int seekerID, string type)
        {
            InitializeComponent();
            this.SeekerID = seekerID;
            Type = type;
        }

        private void LoadSavedData()
        {

            listView1.Items.Clear();
            string connectionString = "Data Source=LAPTOP-JFMTUINJ\\SQLEXPRESS;Initial Catalog=onlineRecruitmentSystem;Integrated Security=True";
            string query = "SELECT Name FROM JobSeeker WHERE JobSeekerID = @seekerID";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@seekerID", SeekerID);

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            Fname.Text = reader["Name"].ToString();
                        }
                    }
                }
            }

            string query1 = "SELECT V.Title, V.Description, V.Industry, V.YearsOfExperience, V.CareerLevel, V.DatePosted, V.Governate, V.City, V.VacancyID, JI.IsSaved FROM JobInterest JI JOIN Vacancy V ON V.VacancyID = JI.VacancyID WHERE JI.JobSeekerID = @seekerID AND JI.IsSaved = 1";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand(query1, connection))
                {
                    command.Parameters.AddWithValue("@seekerID", SeekerID);
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                       
                            while (reader.Read())
                            {
                                ListViewItem item = new ListViewItem(reader["Title"].ToString());
                                item.SubItems.Add(reader["Industry"].ToString());
                                item.SubItems.Add(reader["Description"].ToString());
                                item.SubItems.Add(reader["YearsOfExperience"].ToString());
                                item.SubItems.Add(reader["CareerLevel"].ToString());
                                item.SubItems.Add(reader["Governate"].ToString());
                                item.SubItems.Add(reader["City"].ToString());
                                item.SubItems.Add(reader["DatePosted"].ToString());
                                item.Tag = reader["VacancyID"].ToString();

                                listView1.Items.Add(item);
                            }
                    }
                }
            }
        }
        private void savedVac_Load(object sender, EventArgs e)
        {
            LoadSavedData();
        }

        private void acc_Click(object sender, EventArgs e)
        {
            this.Hide();
            seekerAcc seekerAccount = new seekerAcc(SeekerID, Type);
            seekerAccount.Show();
        }

        private void app_Click(object sender, EventArgs e)
        {

            if (listView1.SelectedItems.Count == 0)
            {
                MessageBox.Show("Please select a vacancy to apply to.");
                return;
            }

            ListViewItem selectedItem = listView1.SelectedItems[0];
            int vacancyID = Convert.ToInt32(selectedItem.Tag);

            string connectionString = "Data Source=LAPTOP-JFMTUINJ\\SQLEXPRESS;Initial Catalog=onlineRecruitmentSystem;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string checkQuery = "SELECT COUNT(*) FROM JobInterest WHERE JobSeekerID = @seekerID AND VacancyID = @vacancyID AND Status ='Applied'";
                using (SqlCommand checkCmd = new SqlCommand(checkQuery, connection))
                {
                    checkCmd.Parameters.AddWithValue("@seekerID", SeekerID);
                    checkCmd.Parameters.AddWithValue("@vacancyID", vacancyID);
                    int count = (int)checkCmd.ExecuteScalar();

                    if (count > 0)
                    {
                        MessageBox.Show("You have already applied for this vacancy.");
                        return;
                    }
                }

                string insertQuery = "UPDATE JobInterest SET Date = @dateapplied, Status = @status WHERE VacancyID = @vacancyID AND JobSeekerID = @seekerID";
                using (SqlCommand command = new SqlCommand(insertQuery, connection))
                {
                    command.Parameters.AddWithValue("@seekerID", SeekerID);
                    command.Parameters.AddWithValue("@vacancyID", vacancyID);
                    command.Parameters.AddWithValue("@dateapplied", DateTime.Now);
                    command.Parameters.AddWithValue("@status", "Applied");

                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Application submitted successfully!");
                    }
                    else
                    {
                        MessageBox.Show("An error occurred while applying. Please try again.");
                    }
                }
            }
        }

        private void del_Click(object sender, EventArgs e)
        {

            if (listView1.SelectedItems.Count == 0)
            {
                MessageBox.Show("Please select vacancy to be removed from saved.");
                return;
            }

            var confirm = MessageBox.Show("Are you sure you want to unsave this vacancy?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (confirm != DialogResult.Yes)
                return;

            ListViewItem selectedItem = listView1.SelectedItems[0];
            int vacID = int.Parse(selectedItem.Tag.ToString());

            string connectionString = "Data Source=LAPTOP-JFMTUINJ\\SQLEXPRESS;Initial Catalog=onlineRecruitmentSystem;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string checkQuery = "SELECT COUNT(JobInterestID) FROM JobInterest WHERE JobSeekerID = @seekerID AND VacancyID = @vacID AND Status = 'Applied'";
                using (SqlCommand checkCmd = new SqlCommand(checkQuery, connection))
                {
                    checkCmd.Parameters.AddWithValue("@seekerID", SeekerID);
                    checkCmd.Parameters.AddWithValue("@vacID", vacID);
                    int count = (int)checkCmd.ExecuteScalar();
                    if (count > 0)
                    {
                        string updateQuery = "UPDATE JobInterest SET IsSaved = 'false' WHERE VacancyID = @vacID AND JobSeekerID = @seekerID";
                        using (SqlCommand updateCmd = new SqlCommand(updateQuery, connection))
                        {
                            updateCmd.Parameters.AddWithValue("@vacID", vacID);
                            updateCmd.Parameters.AddWithValue("@seekerID", SeekerID);
                            int rowsAffected = updateCmd.ExecuteNonQuery();
                            if (rowsAffected > 0)
                            {
                                listView1.Items.Remove(selectedItem);
                                MessageBox.Show("Vacancy removed from saved successfully.");
                                LoadSavedData();
                            }
                            else
                            {
                                MessageBox.Show("Failed to unsave.");
                            }
                        }
                    }
                    else
                    {
                        string deleteQuery = "DELETE FROM JobInterest WHERE VacancyID = @vacID and JobSeekerID = @seekerID";
                        using (SqlCommand command = new SqlCommand(deleteQuery, connection))
                        {
                            command.Parameters.AddWithValue("@vacID", vacID);
                            command.Parameters.AddWithValue("@seekerID", SeekerID);
                            int rowsAffected = command.ExecuteNonQuery();

                            if (rowsAffected > 0)
                            {
                                listView1.Items.Remove(selectedItem);
                                MessageBox.Show("Vacancy removed from saved successfully.");
                                LoadSavedData();
                            }
                            else
                            {
                                MessageBox.Show("Failed to unsave.");
                            }
                        }
                    }
                }
            }
        }
    }
    
}
