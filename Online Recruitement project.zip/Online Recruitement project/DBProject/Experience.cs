﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBProject
{
    public partial class Experience: Form
    {
        private int SeekerID;
        private string type;
        public Experience(int seekerID, string type)
        {
            InitializeComponent();
            this.SeekerID = seekerID;
            this.type = type;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void Experience_Load(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string roleName = Role.Text.Trim();
            string companyName = Company.Text.Trim();
            string durationText = Duration.Text.Trim();
            string descriptionText = Description.Text.Trim();

            if (string.IsNullOrEmpty(roleName) ||
                string.IsNullOrEmpty(companyName) ||
                string.IsNullOrEmpty(durationText) ||
                string.IsNullOrEmpty(descriptionText))
            {
                MessageBox.Show("Please fill all required fields.");
                return;
            }


            string connectionString = "Data Source=LAPTOP-JFMTUINJ\\SQLEXPRESS;Initial Catalog=onlineRecruitmentSystem;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "INSERT INTO Experience (JobSeekerID, Role, Company, Description, Duration) VALUES (@seekerID, @Role, @Company, @Description, @Duration)";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@seekerID", SeekerID);
                    command.Parameters.AddWithValue("@Role", roleName);
                    command.Parameters.AddWithValue("@Company", companyName);
                    command.Parameters.AddWithValue("@Description", descriptionText);
                    command.Parameters.AddWithValue("@Duration", durationText);

                    command.ExecuteNonQuery();

                    MessageBox.Show("Experience added successfully!");
                   
                }
            }
            Role.Text = string.Empty;
            Company.Text = string.Empty;
            Duration.Text = string.Empty;
            Description.Text = string.Empty;
            Role.Focus();

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            viewExperience viewexp = new viewExperience(SeekerID, type);
            viewexp.Show();
        }

        private void acc_Click(object sender, EventArgs e)
        {
            this.Hide();
            seekerAcc acc = new seekerAcc(SeekerID, type);
            acc.Show();
        }
    }
}
