CREATE DATABASE onlineRecruitmentSystem;
GO
USE onlineRecruitmentSystem;
GO

-- Create Employer table (contains all user attributes + employer-specific fields)
CREATE TABLE Employer (
    EmployerID INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(100) NOT NULL,
    Email NVARCHAR(100) NOT NULL UNIQUE,
    Password NVARCHAR(100) NOT NULL,
    Phone NVARCHAR(20),
    Age INT NULL,
    Gender NVARCHAR(10),
    Industry NVARCHAR(100),
    Governate NVARCHAR(100),
    City NVARCHAR(100),
    CompanyName NVARCHAR(100) NOT NULL
);

-- Create JobSeeker table (contains all user attributes + jobseeker-specific fields)
CREATE TABLE JobSeeker (
    JobSeekerID INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(100) NOT NULL,
    Email NVARCHAR(100) NOT NULL UNIQUE,
    Password NVARCHAR(100) NOT NULL,
    Phone NVARCHAR(20),
    Age INT NULL,
    Gender NVARCHAR(10),
    Industry NVARCHAR(100),
    Governate NVARCHAR(100),
    City NVARCHAR(100),
    CVLink NVARCHAR(255),
    YearsOfExperience INT,
    CareerLevel NVARCHAR(50)
);

-- Create Experience table (remains unchanged)
CREATE TABLE Experience (
    ExperienceID INT IDENTITY(1,1) PRIMARY KEY,
    JobSeekerID INT NOT NULL,
    Role NVARCHAR(100) NOT NULL,
    Company NVARCHAR(100) NOT NULL,
    Description NVARCHAR(MAX),
    Duration NVARCHAR(50),
    CONSTRAINT FK_Experience_JobSeeker FOREIGN KEY (JobSeekerID) REFERENCES JobSeeker(JobSeekerID)
);

-- Create Vacancy table (modified to reference Employer directly)
CREATE TABLE Vacancy (
    VacancyID INT IDENTITY(1,1) PRIMARY KEY,
    EmployerID INT NOT NULL,
    Title NVARCHAR(100) NOT NULL,
    Description NVARCHAR(MAX),
    Industry NVARCHAR(100),
    Availability BIT DEFAULT 1,
    YearsOfExperience INT,
    CareerLevel NVARCHAR(50),
    DatePosted DATETIME DEFAULT GETDATE(),
    Governate NVARCHAR(100),
    City NVARCHAR(100),
    CONSTRAINT FK_Vacancy_Employer FOREIGN KEY (EmployerID) REFERENCES Employer(EmployerID)
);

-- Create JobInterest table (modified to reference JobSeeker directly)
CREATE TABLE JobInterest (
    JobInterestID INT IDENTITY(1,1) PRIMARY KEY,
    JobSeekerID INT NOT NULL,
    VacancyID INT NOT NULL,
    [Date] DATETIME DEFAULT GETDATE(),
    Status NVARCHAR(50),
    IsSaved BIT DEFAULT 0,
    CONSTRAINT FK_JobInterest_JobSeeker FOREIGN KEY (JobSeekerID) REFERENCES JobSeeker(JobSeekerID),
    CONSTRAINT FK_JobInterest_Vacancy FOREIGN KEY (VacancyID) REFERENCES Vacancy(VacancyID),
    CONSTRAINT UQ_JobInterest UNIQUE (JobSeekerID, VacancyID)
);


-- INSERTING DUMMY DATA

-- Insert dummy Employers
INSERT INTO Employer (Name, Email, Password, Phone, Age, Gender, Industry, Governate, City, CompanyName)
VALUES
('Ahmed Mohamed', 'ahmed.m@techcorp.com', 'P@ssw0rd123', '01012345678', 35, 'Male', 'Technology', 'Cairo', 'Giza', 'TechCorp Egypt'),
('Mariam Ali', 'mariam.ali@pharmcare.com', 'SecurePass!', '01123456789', 42, 'Female', 'Pharmaceutical', 'Alexandria', 'Alexandria', 'PharmCare International'),
('Omar Hassan', 'omar.hassan@construct.com', 'Build@2023', '01234567890', 38, 'Male', 'Construction', 'Giza', '6th of October', 'Delta Construction'),
('Layla Mahmoud', 'layla@financegroup.com', 'Fin@nce2023', '01567890123', 45, 'Female', 'Banking', 'Cairo', 'Nasr City', 'Egyptian Finance Group'),
('Youssef Ibrahim', 'youssef@retailchain.com', 'Ret@il123', '01098765432', 50, 'Male', 'Retail', 'Cairo', 'Heliopolis', 'National Retail Chain');

-- Insert dummy JobSeekers
INSERT INTO JobSeeker (Name, Email, Password, Phone, Age, Gender, Industry, Governate, City, CVLink, YearsOfExperience, CareerLevel)
VALUES
('Mohamed Samir', 'mohamed.samir@example.com', 'JobSeek@1', '01112223334', 28, 'Male', 'Technology', 'Cairo', 'Maadi', 'https://storage.com/cvs/mohamed_samir.pdf', 3, 'Mid-Level'),
('Aya Mostafa', 'aya.mostafa@example.com', 'AyaPass123', '01023334455', 25, 'Female', 'Marketing', 'Giza', 'Dokki', 'https://storage.com/cvs/aya_mostafa.pdf', 2, 'Entry-Level'),
('Karim Adel', 'karim.adel@example.com', 'K@rim2023', '01234445566', 32, 'Male', 'Engineering', 'Alexandria', 'Smouha', 'https://storage.com/cvs/karim_adel.pdf', 7, 'Senior'),
('Nourhan Wael', 'nourhan.wael@example.com', 'Nourh@n99', '01556667788', 29, 'Female', 'Finance', 'Cairo', 'Zamalek', 'https://storage.com/cvs/nourhan_wael.pdf', 5, 'Mid-Level'),
('Amr Khaled', 'amr.khaled@example.com', 'Kh@led2023', '01067890123', 40, 'Male', 'Healthcare', 'Giza', 'Sheikh Zayed', 'https://storage.com/cvs/amr_khaled.pdf', 15, 'Executive');

-- Insert dummy Experiences for JobSeekers
INSERT INTO Experience (JobSeekerID, Role, Company, Description, Duration)
VALUES
(1, 'Software Developer', 'Tech Solutions Inc.', 'Developed web applications using .NET Core and Angular', '2 years'),
(1, 'Junior Developer', 'Digital Creations', 'Worked on front-end development with React', '1 year'),
(2, 'Marketing Specialist', 'Brand Masters', 'Managed social media campaigns and content creation', '2 years'),
(3, 'Senior Mechanical Engineer', 'Egyptian Engineering Co.', 'Led a team of 5 engineers on industrial projects', '5 years'),
(3, 'Mechanical Engineer', 'Middle East Engineering', 'Designed mechanical systems for commercial buildings', '2 years'),
(4, 'Financial Analyst', 'Cairo Finance Group', 'Prepared financial reports and investment analysis', '3 years'),
(4, 'Accountant', 'National Accounting', 'Managed accounts payable/receivable and payroll', '2 years'),
(5, 'Hospital Administrator', 'MedCare Hospitals', 'Oversaw daily operations of 200-bed hospital', '8 years'),
(5, 'Department Manager', 'City Medical Center', 'Managed HR and operations for pediatrics department', '7 years');

-- Insert dummy Vacancies
INSERT INTO Vacancy (EmployerID, Title, Description, Industry, Availability, YearsOfExperience, CareerLevel, Governate, City)
VALUES
(1, 'Senior .NET Developer', 'Looking for experienced .NET developer to join our team', 'Technology', 1, 5, 'Senior', 'Cairo', 'Giza'),
(1, 'Junior Frontend Developer', 'Entry-level position for fresh graduates', 'Technology', 1, 0, 'Entry-Level', 'Cairo', 'Giza'),
(2, 'Pharmaceutical Sales Rep', 'Sales representative for medical products', 'Pharmaceutical', 1, 2, 'Mid-Level', 'Alexandria', 'Alexandria'),
(3, 'Construction Project Manager', 'Manage large-scale construction projects', 'Construction', 1, 10, 'Senior', 'Giza', '6th of October'),
(4, 'Financial Analyst', 'Analyze market trends and prepare reports', 'Banking', 1, 3, 'Mid-Level', 'Cairo', 'Nasr City'),
(5, 'Store Manager', 'Manage daily operations of retail store', 'Retail', 1, 5, 'Mid-Level', 'Cairo', 'Heliopolis'),
(2, 'Quality Control Specialist', 'Ensure product quality standards', 'Pharmaceutical', 0, 3, 'Mid-Level', 'Alexandria', 'Alexandria');

-- Insert dummy Job Interests
INSERT INTO JobInterest (JobSeekerID, VacancyID, Status, IsSaved)
VALUES
(1, 1, 'Applied', 0),
(1, 2, 'Saved', 1),
(2, 3, 'Applied', 0),
(2, 7, 'Saved', 1),
(3, 4, 'Applied', 0),
(4, 5, 'Applied', 0),
(5, 6, 'Applied', 0),
(3, 1, 'Saved', 1),
(4, 1, 'Saved', 1);



-- EXTRA DUMMY DATA 


-- Additional Employers (10 total)
INSERT INTO Employer (Name, Email, Password, Phone, Age, Gender, Industry, Governate, City, CompanyName)
VALUES
('Hany Kamal', 'hany.kamal@ai-solutions.com', 'AI@2023!', '01011223344', 39, 'Male', 'Artificial Intelligence', 'Cairo', 'New Cairo', 'AI Solutions Egypt'),
('Dina Sherif', 'dina.sherif@edu-eg.com', 'EduC@tion1', '01122334455', 41, 'Female', 'Education', 'Giza', 'Haram', 'Egypt Education Partners'),
('Waleed Nasser', 'waleed@oil-gas.com', 'Petr0leum', '01233445566', 47, 'Male', 'Oil & Gas', 'Suez', 'Suez', 'Nile Petroleum'),
('Farida El-Sayed', 'farida@healthcare.com', 'H3althCare', '01555666777', 36, 'Female', 'Healthcare', 'Cairo', 'Nasr City', 'Premium Healthcare'),
('Tamer Hosny', 'tamer@entertainment.com', 'Medi@1234', '01066778899', 43, 'Male', 'Media & Entertainment', 'Giza', '6th of October', 'Egyptian Media Network');

-- Additional JobSeekers (15 total)
INSERT INTO JobSeeker (Name, Email, Password, Phone, Age, Gender, Industry, Governate, City, CVLink, YearsOfExperience, CareerLevel)
VALUES
('Ramy Essam', 'ramy.essam@example.com', 'Ramy@2023', '01113334455', 27, 'Male', 'Graphic Design', 'Alexandria', 'Miami', 'https://storage.com/cvs/ramy_essam.pdf', 4, 'Mid-Level'),
('Salma Ahmed', 'salma.ahmed@example.com', 'S@lma2023', '01024445566', 24, 'Female', 'Human Resources', 'Cairo', 'Maadi', 'https://storage.com/cvs/salma_ahmed.pdf', 1, 'Entry-Level'),
('Adel Mohsen', 'adel.mohsen@example.com', 'AdelM!23', '01235556677', 33, 'Male', 'Logistics', 'Port Said', 'Port Said', 'https://storage.com/cvs/adel_mohsen.pdf', 8, 'Senior'),
('Dalia Karim', 'dalia.karim@example.com', 'D@lia2023', '01556667788', 29, 'Female', 'Public Relations', 'Cairo', 'Zamalek', 'https://storage.com/cvs/dalia_karim.pdf', 5, 'Mid-Level'),
('Khaled Samy', 'khaled.samy@example.com', 'Kh@ledS23', '01067778899', 45, 'Male', 'Aviation', 'Cairo', 'Heliopolis', 'https://storage.com/cvs/khaled_samy.pdf', 20, 'Executive'),
('Mona Gamal', 'mona.gamal@example.com', 'M0naGamal', '01178889900', 31, 'Female', 'Interior Design', 'Giza', 'Dokki', 'https://storage.com/cvs/mona_gamal.pdf', 6, 'Mid-Level'),
('Ibrahim Fawzy', 'ibrahim.f@example.com', 'Ibr@him1', '01289990011', 26, 'Male', 'Cybersecurity', 'Cairo', 'New Cairo', 'https://storage.com/cvs/ibrahim_fawzy.pdf', 3, 'Mid-Level'),
('Hadeer Waleed', 'hadeer.w@example.com', 'H@deer2023', '01590001122', 28, 'Female', 'Data Science', 'Alexandria', 'San Stefano', 'https://storage.com/cvs/hadeer_waleed.pdf', 4, 'Mid-Level');

-- Additional Experiences (30+ total)
INSERT INTO Experience (JobSeekerID, Role, Company, Description, Duration)
VALUES
(6, 'Graphic Designer', 'Creative Minds', 'Designed marketing materials and brand identities', '3 years'),
(6, 'UI/UX Designer', 'Digital Solutions', 'Created wireframes and prototypes for mobile apps', '1 year'),
(7, 'HR Coordinator', 'People First', 'Managed recruitment processes and onboarding', '1 year'),
(8, 'Logistics Manager', 'Nile Transport', 'Optimized supply chain operations', '5 years'),
(8, 'Warehouse Supervisor', 'Cargo Egypt', 'Managed inventory and shipping operations', '3 years'),
(9, 'PR Specialist', 'Image Consultants', 'Managed corporate communications', '3 years'),
(9, 'Marketing Assistant', 'Brand Vision', 'Supported marketing campaigns', '2 years'),
(10, 'Aircraft Engineer', 'EgyptAir', 'Performed maintenance on Boeing 737 fleet', '12 years'),
(10, 'Aviation Technician', 'Cairo Airport', 'Serviced commercial aircraft', '8 years'),
(11, 'Interior Designer', 'Home Style', 'Designed residential and commercial spaces', '4 years'),
(11, 'Design Consultant', 'Urban Living', 'Provided design solutions for retail spaces', '2 years'),
(12, 'Security Analyst', 'SecureNet', 'Monitored network security and vulnerabilities', '3 years'),
(13, 'Data Analyst', 'InfoTech', 'Analyzed large datasets and created reports', '2 years'),
(13, 'Research Assistant', 'Cairo University', 'Conducted statistical analysis for research projects', '2 years'),
(1, 'Freelance Developer', 'Upwork', 'Completed various web development projects', '1 year'),
(3, 'Consulting Engineer', 'Self-Employed', 'Provided engineering consulting services', '2 years'),
(5, 'Medical Intern', 'Public Hospital', 'Rotated through hospital departments', '1 year');

-- Additional Vacancies (20 total)
INSERT INTO Vacancy (EmployerID, Title, Description, Industry, Availability, YearsOfExperience, CareerLevel, Governate, City)
VALUES
(6, 'Machine Learning Engineer', 'Develop AI models for various applications', 'Artificial Intelligence', 1, 3, 'Mid-Level', 'Cairo', 'New Cairo'),
(7, 'Academic Coordinator', 'Organize educational programs and curricula', 'Education', 1, 2, 'Mid-Level', 'Giza', 'Haram'),
(8, 'Petroleum Engineer', 'Work on oil extraction and processing', 'Oil & Gas', 1, 5, 'Senior', 'Suez', 'Suez'),
(9, 'Registered Nurse', 'Provide patient care in hospital setting', 'Healthcare', 1, 2, 'Mid-Level', 'Cairo', 'Nasr City'),
(10, 'Video Editor', 'Edit video content for media production', 'Media & Entertainment', 1, 3, 'Mid-Level', 'Giza', '6th of October'),
(6, 'Data Annotation Specialist', 'Prepare datasets for AI training', 'Artificial Intelligence', 1, 1, 'Entry-Level', 'Cairo', 'New Cairo'),
(7, 'English Teacher', 'Teach English language to adults', 'Education', 1, 1, 'Entry-Level', 'Giza', 'Haram'),
(1, 'DevOps Engineer', 'Implement CI/CD pipelines and cloud solutions', 'Technology', 0, 4, 'Mid-Level', 'Cairo', 'Giza'),
(3, 'Architectural Engineer', 'Design commercial building structures', 'Construction', 1, 7, 'Senior', 'Giza', '6th of October'),
(4, 'Investment Analyst', 'Analyze financial markets and opportunities', 'Banking', 1, 4, 'Mid-Level', 'Cairo', 'Nasr City'),
(5, 'Retail Supervisor', 'Manage store operations and staff', 'Retail', 1, 3, 'Mid-Level', 'Cairo', 'Heliopolis'),
(9, 'Medical Lab Technician', 'Perform diagnostic testing and analysis', 'Healthcare', 1, 2, 'Mid-Level', 'Cairo', 'Nasr City'),
(10, 'Social Media Manager', 'Manage company social media presence', 'Media & Entertainment', 1, 2, 'Mid-Level', 'Giza', '6th of October'),
(2, 'Pharmacy Manager', 'Oversee pharmacy operations', 'Pharmaceutical', 1, 5, 'Senior', 'Alexandria', 'Alexandria');

-- Additional Job Interests (30+ total)
INSERT INTO JobInterest (JobSeekerID, VacancyID, Status, IsSaved)
VALUES
(4, 8, 'Applied', 0),
(5, 9, 'Applied', 0),
(6, 10, 'Applied', 0),
(7, 11, 'Applied', 0),
(8, 12, 'Applied', 0),
(9, 13, 'Applied', 0),
(10, 14, 'Applied', 0),
(11, 15, 'Applied', 0),
(12, 16, 'Applied', 0),
(13, 17, 'Applied', 0),
(1, 18, 'Saved', 1),
(2, 19, 'Saved', 1),
(3, 20, 'Saved', 1),
(5, 2, 'Saved', 1),
(6, 3, 'Interview Scheduled', 0),
(7, 4, 'Interview Scheduled', 0),
(8, 5, 'Rejected', 0),
(9, 6, 'Offer Received', 0),
(10, 7, 'Offer Received', 0),
(11, 8, 'Withdrawn', 0),
(12, 9, 'Applied', 0),
(13, 10, 'Applied', 0),
(6, 1, 'Saved', 1),
(7, 2, 'Saved', 1),
(8, 3, 'Saved', 1);