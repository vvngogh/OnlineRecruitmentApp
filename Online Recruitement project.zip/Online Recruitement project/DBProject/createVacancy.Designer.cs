﻿namespace DBProject
{
    partial class createVacancy
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Title = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.City = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.YearsOfExperience = new System.Windows.Forms.NumericUpDown();
            this.l = new System.Windows.Forms.Label();
            this.CareerLevel = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.Industry = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.DatePosted = new System.Windows.Forms.DateTimePicker();
            this.Availability = new System.Windows.Forms.ComboBox();
            this.Description = new System.Windows.Forms.RichTextBox();
            this.vacancy = new System.Windows.Forms.Button();
            this.vacList = new System.Windows.Forms.LinkLabel();
            this.governate = new System.Windows.Forms.ComboBox();
            this.acc = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.YearsOfExperience)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(101, 296);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(91, 27);
            this.label2.TabIndex = 1;
            this.label2.Text = "Industry:";
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(102, 93);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(90, 19);
            this.label3.TabIndex = 3;
            this.label3.Text = "Title:";
            this.label3.Click += new System.EventHandler(this.label3_Click_1);
            // 
            // Title
            // 
            this.Title.AccessibleName = "title";
            this.Title.Location = new System.Drawing.Point(261, 90);
            this.Title.Name = "Title";
            this.Title.Size = new System.Drawing.Size(228, 22);
            this.Title.TabIndex = 4;
            this.Title.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(267, 36);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(222, 29);
            this.label4.TabIndex = 5;
            this.label4.Text = "Add New Vacancy";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // City
            // 
            this.City.Location = new System.Drawing.Point(261, 376);
            this.City.Name = "City";
            this.City.Size = new System.Drawing.Size(228, 22);
            this.City.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(102, 153);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(125, 25);
            this.label5.TabIndex = 7;
            this.label5.Text = "Description:";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(102, 211);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(125, 46);
            this.label6.TabIndex = 9;
            this.label6.Text = "Years of Experience:";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // YearsOfExperience
            // 
            this.YearsOfExperience.Location = new System.Drawing.Point(262, 222);
            this.YearsOfExperience.Name = "YearsOfExperience";
            this.YearsOfExperience.Size = new System.Drawing.Size(120, 22);
            this.YearsOfExperience.TabIndex = 10;
            this.YearsOfExperience.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.YearsOfExperience.ValueChanged += new System.EventHandler(this.year_ValueChanged);
            // 
            // l
            // 
            this.l.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l.Location = new System.Drawing.Point(102, 257);
            this.l.Name = "l";
            this.l.Size = new System.Drawing.Size(133, 29);
            this.l.TabIndex = 11;
            this.l.Text = "Career Level:";
            this.l.Click += new System.EventHandler(this.label7_Click);
            // 
            // CareerLevel
            // 
            this.CareerLevel.FormattingEnabled = true;
            this.CareerLevel.Items.AddRange(new object[] {
            "Entry Level",
            "Mid Level",
            "Senior Level",
            "Manager"});
            this.CareerLevel.Location = new System.Drawing.Point(261, 257);
            this.CareerLevel.Name = "CareerLevel";
            this.CareerLevel.Size = new System.Drawing.Size(228, 24);
            this.CareerLevel.TabIndex = 12;
            this.CareerLevel.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(101, 336);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(121, 31);
            this.label8.TabIndex = 13;
            this.label8.Text = "Governorate:";
            // 
            // Industry
            // 
            this.Industry.FormattingEnabled = true;
            this.Industry.Items.AddRange(new object[] {
            "Information Technology (IT) & Software",
            "Finance & Banking",
            "Healthcare & Medical",
            "Education & Training",
            "Engineering",
            "Construction & Real Estate",
            "Sales & Marketing",
            "Customer Service & Call Center",
            "Retail & E-commerce",
            "Manufacturing & Production",
            "Transportation & Logistics",
            "Hospitality & Tourism",
            "Legal Services",
            "Media & Communications",
            "Human Resources (HR)",
            "Science & Research",
            "Government & Public Sector",
            "Nonprofit & NGOs",
            "Arts, Design & Creative",
            "Energy & Utilities",
            "Agriculture & Environment"});
            this.Industry.Location = new System.Drawing.Point(261, 299);
            this.Industry.Name = "Industry";
            this.Industry.Size = new System.Drawing.Size(228, 24);
            this.Industry.TabIndex = 14;
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(101, 376);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(121, 31);
            this.label9.TabIndex = 16;
            this.label9.Text = "City:";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // label11
            // 
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(101, 480);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(121, 31);
            this.label11.TabIndex = 19;
            this.label11.Text = "Availability:";
            // 
            // label12
            // 
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(101, 433);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(121, 31);
            this.label12.TabIndex = 20;
            this.label12.Text = "Date Posted:";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // DatePosted
            // 
            this.DatePosted.Location = new System.Drawing.Point(260, 431);
            this.DatePosted.Name = "DatePosted";
            this.DatePosted.Size = new System.Drawing.Size(200, 22);
            this.DatePosted.TabIndex = 21;
            // 
            // Availability
            // 
            this.Availability.FormattingEnabled = true;
            this.Availability.Items.AddRange(new object[] {
            "Yes ",
            "No"});
            this.Availability.Location = new System.Drawing.Point(261, 480);
            this.Availability.Name = "Availability";
            this.Availability.Size = new System.Drawing.Size(121, 24);
            this.Availability.TabIndex = 22;
            // 
            // Description
            // 
            this.Description.Location = new System.Drawing.Point(260, 134);
            this.Description.Name = "Description";
            this.Description.Size = new System.Drawing.Size(317, 70);
            this.Description.TabIndex = 25;
            this.Description.Text = "";
            this.Description.TextChanged += new System.EventHandler(this.richTextBox1_TextChanged);
            // 
            // vacancy
            // 
            this.vacancy.BackColor = System.Drawing.Color.Gold;
            this.vacancy.Cursor = System.Windows.Forms.Cursors.Hand;
            this.vacancy.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vacancy.Location = new System.Drawing.Point(272, 581);
            this.vacancy.Name = "vacancy";
            this.vacancy.Size = new System.Drawing.Size(178, 52);
            this.vacancy.TabIndex = 64;
            this.vacancy.Text = "Add Vacancy";
            this.vacancy.UseVisualStyleBackColor = false;
            this.vacancy.Click += new System.EventHandler(this.vacancy_Click);
            // 
            // vacList
            // 
            this.vacList.AutoSize = true;
            this.vacList.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vacList.Location = new System.Drawing.Point(462, 613);
            this.vacList.Name = "vacList";
            this.vacList.Size = new System.Drawing.Size(142, 20);
            this.vacList.TabIndex = 65;
            this.vacList.TabStop = true;
            this.vacList.Text = "View Vacancies";
            this.vacList.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.expList_LinkClicked);
            // 
            // governate
            // 
            this.governate.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.governate.FormattingEnabled = true;
            this.governate.Items.AddRange(new object[] {
            "Alexandria",
            "Aswan",
            "Asyut",
            "Beheira",
            "Beni Suef",
            "Cairo",
            "Dakahlia",
            "Damietta",
            "Faiyum",
            "Gharbia",
            "Giza",
            "Ismailia",
            "Kafr El Sheikh",
            "Luxor",
            "Matrouh",
            "Minya",
            "Monufia",
            "New Valley",
            "North Sinai",
            "Port Said",
            "Qalyubia",
            "Qena",
            "Red Sea",
            "Sharqia",
            "Sohag",
            "South Sinai",
            "Suez"});
            this.governate.Location = new System.Drawing.Point(260, 336);
            this.governate.Name = "governate";
            this.governate.Size = new System.Drawing.Size(229, 24);
            this.governate.TabIndex = 66;
            // 
            // acc
            // 
            this.acc.BackColor = System.Drawing.Color.Gold;
            this.acc.Cursor = System.Windows.Forms.Cursors.Hand;
            this.acc.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.acc.Location = new System.Drawing.Point(88, 581);
            this.acc.Name = "acc";
            this.acc.Size = new System.Drawing.Size(147, 52);
            this.acc.TabIndex = 94;
            this.acc.Text = "Account";
            this.acc.UseVisualStyleBackColor = false;
            this.acc.Click += new System.EventHandler(this.acc_Click);
            // 
            // createVacancy
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Ivory;
            this.ClientSize = new System.Drawing.Size(708, 746);
            this.Controls.Add(this.acc);
            this.Controls.Add(this.governate);
            this.Controls.Add(this.vacList);
            this.Controls.Add(this.vacancy);
            this.Controls.Add(this.Description);
            this.Controls.Add(this.Availability);
            this.Controls.Add(this.DatePosted);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.Industry);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.CareerLevel);
            this.Controls.Add(this.l);
            this.Controls.Add(this.YearsOfExperience);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.City);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Title);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Black;
            this.Name = "createVacancy";
            this.Text = "create a New Vacancy";
            this.Load += new System.EventHandler(this.createVacancy_Load);
            ((System.ComponentModel.ISupportInitialize)(this.YearsOfExperience)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox Title;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox City;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown YearsOfExperience;
        private System.Windows.Forms.Label l;
        private System.Windows.Forms.ComboBox CareerLevel;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox Industry;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.DateTimePicker DatePosted;
        private System.Windows.Forms.ComboBox Availability;
        private System.Windows.Forms.RichTextBox Description;
        private System.Windows.Forms.Button vacancy;
        private System.Windows.Forms.LinkLabel vacList;
        private System.Windows.Forms.ComboBox governate;
        private System.Windows.Forms.Button acc;
    }
}